INSERT INTO dog(country, active, death, recovered) VALUES('country1', 20, 1,2);
INSERT INTO dog(country, active, death, recovered) VALUES('country2', 99, 6,1);
INSERT INTO dog(country, active, death, recovered) VALUES('country3', 80, 3,0);
INSERT INTO dog(country, active, death, recovered) VALUES('country4', 60, 7,3);
INSERT INTO dog(country, active, death, recovered) VALUES('country5', 60, 5,6);
INSERT INTO dog(country, active, death, recovered) VALUES('country6', 550, 2,77);
INSERT INTO dog(country, active, death, recovered) VALUES('country7', 670, 4,88);
